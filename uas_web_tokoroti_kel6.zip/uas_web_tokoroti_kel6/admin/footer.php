<footer style="background-color: gray;padding: 1px;" class="print">
	<h5 class="text-center">Copyright&copy; kelompok6</h5>
</footer>
</body>
</html>